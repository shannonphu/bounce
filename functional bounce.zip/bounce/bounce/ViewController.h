//
//  ViewController.h
//  bounce
//
//  Created by Shannon Phu on 7/16/15.
//  Copyright (c) 2015 Shannon Phu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) UIColor *centralColor;
@property (strong, nonatomic) NSArray *colorPalette;
//- (void)setRandomColorPaletteForView;
@end

